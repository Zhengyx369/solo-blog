title: Servlet笔记
date: '2019-10-14 04:11:03'
updated: '2019-10-14 04:12:54'
tags: [Servlet]
permalink: /articles/2019/10/14/1571026263080.html
---
# Servlet

### 示例:获取参数

##### 1. login.html

form元素中：
	action="login" 标题会提交到login路径，login路径在后续步骤会映射到LoginServlet
	method="post" post方式表示提交的密码信息在浏览器地址栏看不到

```html
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>登录页面</title>
</head>
<body>
  
<form action="login" method="post">
账号: <input type="text" name="name"> <br>
密码: <input type="password" name="password"> <br>
<input type="submit" value="登录">
</form>
  
</body>
</html>
```



##### 2. LoginServlet

在doPost方法中，通过**request.getParameter** 根据name取出对应的账号和密码, 响应

```java
import java.io.IOException;
 
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
  
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String password = request.getParameter("password");
  
        System.out.println("name:" + name);
        System.out.println("password:" + password);
        
        if ("admin".equals(name) && "123".equals(password))
            html = "<div style='color:green'>success</div>";
        else
            html = "<div style='color:red'>fail</div>";
  
        PrintWriter pw = response.getWriter();
        pw.println(html);
    }
}
```

##### 3.web.xml中新增映射

```xml
<?xml version="1.0" encoding="UTF-8"?>
<web-app>

    <servlet>
        <servlet-name>LoginServlet</servlet-name>
        <servlet-class>LoginServlet</servlet-class>
    </servlet>
 
    <servlet-mapping>
        <servlet-name>LoginServlet</servlet-name>
        <url-pattern>/login</url-pattern>
    </servlet-mapping>   
 
</web-app>
```

### Servlet调用流程

![img](http://how2j.cn/img/site/step/7461.png)

一个静态的html页面，可以通过form，以post的形式提交数据 等

上一步的login.html中，用form，把账号和密码，提交到/login这个路径，并且附带method="post"

路径是/login，接着就到[配置文件web.xml](http://how2j.cn/k/servlet/servlet-paramter/547.html#step1588)进行匹配，发现/login，对应的Servlet类是 LoginServlet

没有LoginServlet的实例存在，于是调用LoginServlet的public无参的构造方法LoginServlet()实例化一个LoginServlet对象以备后续使用

拿到了LoginServlet的实例之后，根据页面login.html提交信息的时候带的method="post"，去调用对应的doPost方法

doPost方法中，通过参数request，把页面上传递来的账号和密码信息取出来，根据账号和密码是否正确， 创建不同的html字符串，设置在了response对象上。

Tomcat把最终HTML传递给浏览器

### doGet() 、doPost(）、service()

当浏览器使用get方式提交数据的时候，servlet需要提供doGet()方法

当浏览器使用post方式提交数据的时候，servlet需要提供doPost()方法



在执行doGet()或者doPost()之前，都会先执行service()

由service()方法进行判断，到底该调用doGet()还是doPost()

可以发现，service(), doGet(), doPost() 三种方式的参数列表都是一样的。

所以，有时候也会**直接重写service()**方法，在其中提供相应的服务，就不用区分到底是get还是post了。

### Servlet中文问题

html

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">



在servlet进行解码和编码

【方法一】：request之后，先根据ISO-8859-1解码，然后用UTF-8编码

```java
String name = request.getParameter("name");

byte[] bytes=  name.getBytes("ISO-8859-1");

name = new String(bytes,"UTF-8");
```

【方法二】：request之前，使用UTF-8的方式

```java
request.setCharacterEncoding("UTF-8"); 
String password = request.getParameter("password");

```

response使用前，设置编码

```Java
response.setContentType("text/html; charset=UTF-8");

PrintWriter pw = response.getWriter();

pw.println(html);
```

### Servlet生命周期

Servlet的生命周期由 **实例化，初始化，提供服务，销毁，被回收**组成

（1）实例化：

用户通过浏览器输入一个路径，这个路径对应的servlet被调用的时候，该Servlet就会被实例化

无论访问了多少次LoginServlet，oginServlet构造方法 **只会执行一次**，所以Servlet是**单实例的**

（2）初始化：

LoginServlet **继承了HttpServlet**，同时也继承了init(ServletConfig) 方法

init 方法是一个实例方法，所以会在构造方法执行后执行。

无论访问了多少次LoginSerlvet，init初始化 **只会执行一次**

（3）提供服务：

执行service()方法，然后通过浏览器传递过来的信息进行判断，是调用doGet()还是doPost()方法

（4）销毁

该Servlet所在的web应用重新启动时；

关闭tomcat的时候 destroy()方法会被调用

（5）被回收

当该Servlet被销毁后，就满足垃圾回收的条件了。 当下一次垃圾回收GC来临的时候，就可能被回收。

### Servlet跳转



```java
if ("admin".equals(name) && "123".equals(password)) {
  	request.getRequestDispatcher("success.html").forward(request, response);
        }
else{
    response.sendRedirect("fail.html");
        }
```

服务端跳转可以看到浏览器的地址依然是/login 路径，并不会变成success.html

```java
request.getRequestDispatcher("success.html").forward(request, response);
```

客户端跳转，浏览器地址发生了变化

```java
response.sendRedirect("fail.html");
```

![æå¡ç«¯è·³è½¬ä¸å®¢æ·ç«¯è·³è½¬å¾ç¤º](http://stepimagewm.how2j.cn/1602.png)

### Servlet自启动

在web.xml中，配置Hello Servlet的地方，增加一句
 <load-on-startup>10</load-on-startup> 

取值范围是1-99，数字越小，启动的优先级越高。

表明该Servlet会随着Tomcat的启动而初始化。



### Servlet request的常见方法

**request.getRequestURL():** 浏览器发出请求时的完整URL，包括协议 主机名 端口(如果有)" 
**request.getRequestURI():** 浏览器发出请求的资源名部分，去掉了协议和主机名" 
**request.getQueryString():** 请求行中的参数部分，只能显示以get方式发出的参数，post方式的看不到
**request.getRemoteAddr():** 浏览器所处于的客户机的IP地址
**request.getRemoteHost():** 浏览器所处于的客户机的主机名
**request.getRemotePort():** 浏览器所处于的客户机使用的网络端口
**request.getLocalAddr():** 服务器的IP地址
**request.getLocalName():** 服务器的主机名
**request.getMethod():** 得到客户机请求方式一般是GET或者POST

![1565159978747.png](https://img.hacpai.com/file/2019/10/1565159978747-53b6f289.png)


**request.getParameter()**: 是常见的方法，用于获取单值的参数

**request.getParameterValues():** 用于获取具有多值的参数

**request.getParameterMap():** 用于遍历所有的参数，并返回Map类型。

```java
System.out.println("获取单值参数name:" + request.getParameter("name"));
 
String[] hobits = request.getParameterValues("hobits");
System.out.println("获取具有多值的参数hobits: " + Arrays.asList(hobits));
 
System.out.println("通过 getParameterMap 遍历所有的参数： ");
Map<String, String[]> parameters = request.getParameterMap();
 
Set<String> paramNames = parameters.keySet();
for (String param : paramNames) {
       String[] value = parameters.get(param);
       System.out.println(param + ":" + Arrays.asList(value));
}
```

**request.getHeader()** 获取浏览器传递过来的头信息。 
比如getHeader("user-agent") 可以获取浏览器的基本资料，这样就能判断是firefox、IE、chrome、或者是safari浏览器

**request.getHeaderNames()** 获取浏览器所有的**头信息名称**，根据头信息名称就能遍历出所有的头信息

```java
Enumeration<String> headerNames= request.getHeaderNames();
while(headerNames.hasMoreElements()){
     String header = headerNames.nextElement();
     String value = request.getHeader(header);
     System.out.printf("%s\t%s%n",header,value);
    }
```

### Servlet response用法

##### 1.响应内容

通过response.getWriter(); 获取一个PrintWriter 对象
可以使用println(),append(),write(),format()等等方法设置返回给浏览器的html内容。

```java
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
public class HelloServlet extends HttpServlet{
     
    public void doGet(HttpServletRequest request, HttpServletResponse response){
         
        try {
            PrintWriter pw= response.getWriter();
            pw.println("<h1>Hello Servlet</h1>");
             
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }   
}
```

##### 2.响应格式

response.setContentType("text/html");

"text/html" 是存在的，表示浏览器可以识别这种格式，如果换一个其他的格式， 比如 "text/lol" ，浏览器不能识别，那么打开此servlet就会弹出一个下载的对话框。

这样的手段也就常常用于实现下载功能

##### 3. 响应编码

设置响应编码有两种方式

 1. response.setContentType("text/html; charset=UTF-8");
  2. response.setCharacterEncoding("UTF-8");

都需要在response.getWriter调用之前执行才能生效。

区别在于：

```
 response.setContentType("text/html; charset=UTF-8");
```

​	发送到浏览器的内容会使用UTF-8编码，而且还通知浏览器使用UTF-8编码方式进行显示。所以总能正常显示中文

```
response.setCharacterEncoding("UTF-8"); 
```

​	仅仅是发送的浏览器的内容是UTF-8编码的，至于浏览器是用哪种编码方式显示不管。 所以当浏览器的显示编码方式不是UTF-8的时候，就会看到乱码，需要手动再进行一次设置。

##### 4. 301和302跳转

302 表示临时跳转，301 表示永久性跳转

302        --->             response.sendRedirect("fail.html");

301        --->             response.setStatus(301);

​									response.setHeader("Location", "fail.html");

#####  5. 设置关闭缓存

```
response.setDateHeader("Expires",0 );

response.setHeader("Cache-Control","no-cache");

response.setHeader("pragma","no-cache");
```

 
